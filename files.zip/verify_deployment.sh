#!/bin/bash
# 🧪 方案5快速驗證腳本
# 用於驗證 BigSeller API + Cookie 管理是否正常運作

BASE_URL="https://yindan-system-production.up.railway.app"

echo "🚀 開始方案5驗證..."
echo "======================================="

# 1. 檢查系統狀態
echo "1️⃣ 檢查系統狀態..."
curl -s "$BASE_URL/" > /dev/null
if [ $? -eq 0 ]; then
    echo "   ✅ Railway 系統運行中"
else
    echo "   ❌ Railway 系統無法訪問"
    exit 1
fi

# 2. 檢查 Cookie 健康狀態
echo "2️⃣ 檢查 Cookie 健康狀態..."
COOKIE_HEALTH=$(curl -s "$BASE_URL/api/superman-glasses/cookie-health")
echo "   回應: $COOKIE_HEALTH"

# 提取 Cookie 狀態
STATUS=$(echo $COOKIE_HEALTH | grep -o '"status":"[^"]*' | cut -d'"' -f4)
echo "   Cookie 狀態: $STATUS"

case $STATUS in
    "healthy")
        echo "   ✅ Cookie 狀態良好"
        ;;
    "missing")
        echo "   🟡 無 Cookie，需要上傳"
        ;;
    "warning")
        echo "   🟡 Cookie 有警告"
        ;;
    "critical")
        echo "   🔴 Cookie 狀態危險"
        ;;
    *)
        echo "   ❓ Cookie 狀態未知: $STATUS"
        ;;
esac

# 3. 檢查廣告日誌 API
echo "3️⃣ 檢查廣告日誌 API..."
AD_LOG=$(curl -s "$BASE_URL/api/superman-glasses/ad-log")
COOKIE_OK=$(echo $AD_LOG | grep -o '"cookie_ok":[^,]*' | cut -d':' -f2)
COST_COUNT=$(echo $AD_LOG | grep -o '"cost_count":[^,]*' | cut -d':' -f2)

echo "   Cookie 可用: $COOKIE_OK"
echo "   成本資料筆數: $COST_COUNT"

# 4. 執行診斷檢查
echo "4️⃣ 執行排程診斷..."
DEBUG_RESULT=$(curl -s -X POST "$BASE_URL/api/superman-glasses/debug-hourly")
echo "   診斷結果片段: $(echo $DEBUG_RESULT | head -c 200)..."

# 5. 檢查是否有廣告資料
STEPS=$(echo $DEBUG_RESULT | grep -o '廣告: [0-9]* 筆')
if [ -n "$STEPS" ]; then
    echo "   ✅ $STEPS"
else
    echo "   ❓ 無法取得廣告資料"
fi

echo "======================================="
echo "🎯 驗證完成"

if [ "$COOKIE_OK" = "true" ] && [ "$COST_COUNT" -gt 0 ]; then
    echo "✅ 系統狀態良好，自動化應該可以正常運作"
else
    echo "⚠️  系統需要調整："
    [ "$COOKIE_OK" != "true" ] && echo "   - 需要上傳 Cookie"
    [ "$COST_COUNT" -le 0 ] && echo "   - 需要同步成本資料"
fi

echo ""
echo "🔗 有用連結："
echo "   健康檢查: $BASE_URL/api/superman-glasses/cookie-health"
echo "   廣告戰情室: $BASE_URL (首頁下方)"
echo "   診斷工具: $BASE_URL/api/superman-glasses/debug-hourly"
